package Floristeria;

public class Casa {
    //Atributos de clase
	private String color;
	private int numHabitaciones;
	private boolean tienePatio;
	private boolean tieneParqueadero;
	private int numBanos;
	
	/**
	 * Constructor de la clase casa
	 * @param color color de la casa 
	 * @param numHabitaciones numero de habitaciones de la casa
	 * @param numBanos numero de baños de la casa
	 * @param tienePatio coloque true or false dependiendo si hay o no patio
	 * @param tieneParqueadero coloque true o false si tiene parqueadero o no 
	 */
	public Casa(String color,int numHabitaciones,int numBanos,boolean tieneParqueadero,boolean tienePatio) {
	    this.color=color;
	    this.numHabitaciones=numHabitaciones;
		this.numBanos=numBanos;	 
		this.tienePatio=tienePatio;
		this.tieneParqueadero=tieneParqueadero;
	}
	
	public String describir() {
		String descripcion="La casa es de dolor" + this.color + 
				". Tiene" + this.numHabitaciones + " habitacion(es) y " + 
				this.numBanos + " bano(s).";
		if (tienePatio) {descripcion+="\nTiene Patio.";}
		if (tieneParqueadero) {descripcion+="\nTiene Parqueadero";}
		return descripcion;
	}
	public void pintar(String nuevoColor) {
		this.color=nuevoColor;
		System.out.println("La casa ha sido pintada de color " + this.color);
	}
}
